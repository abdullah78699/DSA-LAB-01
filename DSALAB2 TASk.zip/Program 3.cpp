#include <iostream>
using namespace std;
int main() {
int num = 42;
int *ptr = &num;
cout << "Value of num: " << num << endl;
cout << "Value pointed to by ptr: " << *ptr << endl;
*ptr = 100;
cout << "Updated value of num: " << num << endl;
return 0;
}
