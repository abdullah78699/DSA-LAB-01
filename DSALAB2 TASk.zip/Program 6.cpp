#include <iostream>
using namespace std;
int main() {
int num1 = 20; int num2 = 8;
int difference = 0; int *ptr1 = &num1; int *ptr2 = &num2;
difference = *ptr1 - *ptr2;
cout << "Difference between " << *ptr1 << " and " << *ptr2 << " is: " << difference << endl; 
return 0;
}
