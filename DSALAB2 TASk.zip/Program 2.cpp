#include <iostream> 
using namespace std; 
int main() {
int *p;
int arr[] = { 3, 4, 6, 34, 5, 44 };
p = arr;
for (int x = 0; x < 6; x++) { cout << *p << endl; p++;
}
return 0;
}
