#include <iostream>
using namespace std;
int main() {
int num1 = 5; int num2 = 10; int sum = 0;
int *ptr1 = &num1; int *ptr2 = &num2; sum = *ptr1 + *ptr2;
cout << "Sum of " << *ptr1 << " and " << *ptr2 << " is: " << sum << endl; 
return 0;
}
 

