#include <iostream> 
using namespace std;
int main() {
int numbers[] = {1, 2, 3, 4, 5, 6, 7, 8, 9}; int countOdd = 0;
int *ptr = numbers;
for (int i = 0; i < sizeof(numbers) / sizeof(numbers[0]); i++) 
{ if (*ptr % 2 != 0) {
countOdd++;
}
ptr++;
}
cout << "Count of odd numbers in the array: " << countOdd << endl; 
return 0;
}

