#include <iostream> 
using namespace std;
int main() {
int numbers[] = {1, 2, 3, 4, 5, 6, 7, 8, 9}; 
int countEven = 0;
int *ptr = numbers;
for (int i = 0; i < sizeof(numbers) / sizeof(numbers[0]); i++) { if (*ptr % 2 == 0) {
countEven++;
}
ptr++;
}
cout << "Count of even numbers in the array: " << countEven << endl; 
return 0;
}
