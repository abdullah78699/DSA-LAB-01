#include <iostream> 
using namespace std;
int main() { 
int a = 10; int b = 20;
int *ptr1 = &a; int *ptr2 = &b;
cout << "The value of a: " << *ptr1 << endl; cout << "The value of b: " << *ptr2 << endl;
int temp = *ptr1;
*ptr1 = *ptr2;
*ptr2 = temp; 
cout << "After swapping:" << endl;
cout << "The value of a: " << *ptr1 << endl; cout << "The value of b: " << *ptr2 << endl;
return 0;
}

