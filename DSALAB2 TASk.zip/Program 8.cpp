#include <iostream> 
using namespace std;
int main() {
double num1 = 30.0; double num2 = 6.0; double result = 0.0;
double *ptr1 = &num1; double *ptr2 = &num2;
if (*ptr2 != 0.0) {
result = *ptr1 / *ptr2;
cout << "Result of division: " << *ptr1 << " / " << *ptr2 << " = " << result << endl;
} 
else {
cout << "Error: Division by zero is not allowed." << endl;
}
return 0;
}

