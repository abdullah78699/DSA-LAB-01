#include <iostream>
using namespace std;
int main() {
int num1 = 6; int num2 = 7; int product = 0;
int *ptr1 = &num1; int *ptr2 = &num2;
product = (*ptr1) * (*ptr2);
cout << "Product of " << *ptr1 << " and " << *ptr2 << " is: " << product << endl;
return 0;
}

