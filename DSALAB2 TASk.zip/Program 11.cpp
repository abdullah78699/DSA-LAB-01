#include <iostream> 
using namespace std;
void square(int *num) {
*num = (*num) * (*num);
}
int main() {
int number = 5;
cout << "Before squaring: " << number << endl; square(&number);
cout << "After squaring: " << number << endl;
return 0;
}

